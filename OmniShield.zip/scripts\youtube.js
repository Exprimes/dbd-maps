/**
 * StreamShield - YouTube Ad Blocker & Enhancer Script v1.4
 * Handles in-stream video ads, banner ads, anti-adblock detection, quality forcing, and master switch.
 */

(function () {
  'use strict';

  let isEnabled = true;
  let isAdCurrentlyActive = false;
  let originalMutedState = false;
  let originalPlaybackRate = 1.0;

  function updateDOMState() {
    if (isEnabled) {
      document.documentElement.classList.remove('streamshield-disabled');
      document.documentElement.classList.remove('omnishield-disabled');
    } else {
      document.documentElement.classList.add('streamshield-disabled');
      document.documentElement.classList.add('omnishield-disabled');
      const video = document.querySelector('video');
      if (video) {
        video.playbackRate = 1.0;
        if (isAdCurrentlyActive) {
          video.muted = originalMutedState;
        }
      }
      isAdCurrentlyActive = false;
    }
  }

  // Sync settings with MAIN world
  function syncSettings() {
    chrome.storage.local.get(
      [
        'streamShieldEnabled',
        'youtubeEnabled',
        'autoMaxQuality',
        'volumeNormalize',
        'volumeBoost'
      ],
      (res) => {
        isEnabled = (res.streamShieldEnabled !== false) && (res.youtubeEnabled !== false);
        updateDOMState();

        window.postMessage({
          type: 'STREAMSHIELD_AUDIO_CONFIG',
          normalizer: isEnabled ? (res.volumeNormalize ?? false) : false,
          boost: isEnabled ? (res.volumeBoost ?? 1.0) : 1.0
        }, '*');

        window.postMessage({
          type: 'STREAMSHIELD_QUALITY_CONFIG',
          autoMaxQuality: isEnabled ? (res.autoMaxQuality ?? true) : false
        }, '*');
      }
    );
  }

  syncSettings();

  // Listen for setting changes in real-time
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.streamShieldEnabled !== undefined || changes.youtubeEnabled !== undefined) {
        chrome.storage.local.get(['streamShieldEnabled', 'youtubeEnabled'], (res) => {
          isEnabled = (res.streamShieldEnabled !== false) && (res.youtubeEnabled !== false);
          updateDOMState();
        });
      }

      if (changes.volumeNormalize !== undefined || changes.volumeBoost !== undefined) {
        chrome.storage.local.get(['volumeNormalize', 'volumeBoost', 'streamShieldEnabled'], (res) => {
          const active = res.streamShieldEnabled !== false;
          window.postMessage({
            type: 'STREAMSHIELD_AUDIO_CONFIG',
            normalizer: active ? (res.volumeNormalize ?? false) : false,
            boost: active ? (res.volumeBoost ?? 1.0) : 1.0
          }, '*');
        });
      }

      if (changes.autoMaxQuality !== undefined) {
        chrome.storage.local.get(['streamShieldEnabled'], (res) => {
          const active = res.streamShieldEnabled !== false;
          window.postMessage({
            type: 'STREAMSHIELD_QUALITY_CONFIG',
            autoMaxQuality: active ? changes.autoMaxQuality.newValue : false
          }, '*');
        });
      }
    }
  });

  function reportBlockedAd(count = 1) {
    if (!isEnabled) return;
    chrome.runtime.sendMessage({ action: 'adBlocked', platform: 'youtube', count }).catch(() => {});
  }

  function cleanBanners() {
    if (!isEnabled) return;

    const bannerSelectors = [
      'ytd-ad-slot-renderer',
      'ytd-in-feed-ad-layout-renderer',
      '#masthead-ad',
      'ytd-banner-promo-renderer',
      'ytd-promoted-sparkles-web-renderer',
      'ytd-promoted-sparkles-text-search-renderer',
      'ytd-display-ad-renderer',
      '#player-ads',
      '.ytd-player-legacy-desktop-watch-ads-renderer',
      'ytd-action-companion-ad-renderer',
      'ytd-compact-promoted-video-renderer'
    ];

    let found = 0;
    for (const selector of bannerSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const el of elements) {
        if (!el.dataset.ssBlocked) {
          el.dataset.ssBlocked = 'true';
          el.style.display = 'none';
          found++;
        }
      }
    }

    if (found > 0) {
      reportBlockedAd(found);
    }
  }

  function handleAntiAdblockModal() {
    if (!isEnabled) return;

    const dialog = document.querySelector('ytd-enforcement-message-view-model, tp-yt-paper-dialog:has(ytd-enforcement-message-view-model)');
    if (dialog) {
      const dismissBtn = dialog.querySelector('#dismiss-button, button[aria-label*="Fermer"], button[aria-label*="Dismiss"], yt-button-renderer button');
      if (dismissBtn) {
        dismissBtn.click();
      } else {
        dialog.remove();
      }

      document.querySelectorAll('tp-yt-iron-overlay-backdrop').forEach(b => b.remove());

      const video = document.querySelector('video.html5-main-video') || document.querySelector('video');
      if (video && video.paused) {
        video.play().catch(() => {});
      }

      reportBlockedAd(1);
    }
  }

  function processVideoAds() {
    if (!isEnabled) return;

    const moviePlayer = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
    const video = document.querySelector('video.html5-main-video') || document.querySelector('video');

    if (!moviePlayer || !video) return;

    const isAdShowing = moviePlayer.classList.contains('ad-showing') ||
                        moviePlayer.classList.contains('ad-interrupting') ||
                        !!document.querySelector('.ytp-ad-player-overlay') ||
                        !!document.querySelector('.ytp-ad-module:not(:empty)');

    if (isAdShowing) {
      if (!isAdCurrentlyActive) {
        isAdCurrentlyActive = true;
        originalMutedState = video.muted;
        originalPlaybackRate = video.playbackRate || 1.0;
        reportBlockedAd(1);
      }

      try {
        video.muted = true;
        video.playbackRate = 16.0;

        if (isFinite(video.duration) && video.duration > 0) {
          video.currentTime = video.duration + 0.1;
        }
      } catch (e) {}

      const skipSelectors = [
        '.ytp-ad-skip-button',
        '.ytp-ad-skip-button-modern',
        '.ytp-skip-ad-button',
        'button.ytp-ad-skip-button-modern',
        '.ytp-ad-overlay-close-button',
        '[id^="skip-button:"] button'
      ];

      for (const selector of skipSelectors) {
        const btn = document.querySelector(selector);
        if (btn) {
          btn.click();
          break;
        }
      }
    } else {
      if (isAdCurrentlyActive) {
        isAdCurrentlyActive = false;
        video.muted = originalMutedState;
        video.playbackRate = originalPlaybackRate || 1.0;
      }
    }

    handleAntiAdblockModal();
  }

  setInterval(processVideoAds, 50);
  setInterval(cleanBanners, 500);

  const observer = new MutationObserver(() => {
    if (!isEnabled) return;
    cleanBanners();
    handleAntiAdblockModal();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  console.log('[StreamShield] YouTube engine active.');
})();
