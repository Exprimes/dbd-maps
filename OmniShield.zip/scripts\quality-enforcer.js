/**
 * OmniShield - Quality Enforcer & YouTube Core Interceptor (Main World)
 * 1. Prunes adPlacements from ytInitialPlayerResponse, JSON.parse, and /youtubei/v1/player
 * 2. Enforces maximum resolution (HD / 1440p / 4K) on YouTube without interrupting playback
 * 3. Enforces Source ("chunked") quality on Twitch
 */

(function () {
  'use strict';

  // =========================================================================
  // 1. YOUTUBE ZERO-AD & ZERO-BLACK-SCREEN ENGINE (MAIN WORLD)
  // =========================================================================
  if (window.location.hostname.includes('youtube.com')) {
    function cleanAds(data) {
      if (!data || typeof data !== 'object') return data;
      try {
        if (data.adPlacements) delete data.adPlacements;
        if (data.playerAds) delete data.playerAds;
        if (data.adSlots) delete data.adSlots;
        if (data.adBreakHeartbeatParams) delete data.adBreakHeartbeatParams;
        if (data.playerResponse && typeof data.playerResponse === 'object') {
          cleanAds(data.playerResponse);
        }
      } catch (e) {}
      return data;
    }

    // Intercept window.ytInitialPlayerResponse
    let _ytInitialPlayerResponse = window.ytInitialPlayerResponse;
    if (_ytInitialPlayerResponse) {
      cleanAds(_ytInitialPlayerResponse);
    }
    try {
      Object.defineProperty(window, 'ytInitialPlayerResponse', {
        get() {
          return _ytInitialPlayerResponse;
        },
        set(val) {
          _ytInitialPlayerResponse = cleanAds(val);
        },
        configurable: true
      });
    } catch (e) {}

    // Intercept JSON.parse
    try {
      const realJSONParse = JSON.parse;
      JSON.parse = function (...args) {
        const obj = realJSONParse.apply(this, args);
        if (obj && typeof obj === 'object') {
          if (
            obj.adPlacements ||
            obj.playerAds ||
            obj.adSlots ||
            (obj.playerResponse && (obj.playerResponse.adPlacements || obj.playerResponse.playerAds))
          ) {
            cleanAds(obj);
          }
        }
        return obj;
      };
    } catch (e) {}

    // Intercept fetch for /youtubei/v1/player and /youtubei/v1/next
    try {
      const realFetch = window.fetch;
      if (typeof realFetch === 'function') {
        window.fetch = async function (...args) {
          const response = await realFetch.apply(this, args);
          try {
            const url = args[0] ? (typeof args[0] === 'string' ? args[0] : args[0].url) : '';
            if (url && (url.includes('/youtubei/v1/player') || url.includes('/youtubei/v1/next'))) {
              const clone = response.clone();
              const data = await clone.json();
              cleanAds(data);
              return new Response(JSON.stringify(data), {
                status: response.status,
                statusText: response.statusText,
                headers: response.headers
              });
            }
          } catch (e) {}
          return response;
        };
      }
    } catch (e) {}
  }

  // =========================================================================
  // 2. QUALITY ENFORCEMENT & SETTINGS
  // =========================================================================
  let autoMaxQualityEnabled = true;

  function handleYouTubeQuality() {
    if (!autoMaxQualityEnabled) return;
    if (!window.location.hostname.includes('youtube.com')) return;

    try {
      const player = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
      if (!player) return;

      const isAd = player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting');
      if (isAd) return;

      if (typeof player.getAvailableQualityLevels === 'function') {
        const levels = player.getAvailableQualityLevels();
        if (levels && levels.length > 0) {
          const highest = levels[0];
          const current = typeof player.getPlaybackQuality === 'function' ? player.getPlaybackQuality() : '';

          if (current !== highest && highest !== 'auto') {
            if (typeof player.setPlaybackQualityRange === 'function') {
              player.setPlaybackQualityRange(highest, highest);
            }
            if (typeof player.setPlaybackQuality === 'function') {
              player.setPlaybackQuality(highest);
            }
          }
        }
      }
    } catch (e) {}
  }

  function enforceTwitchQuality() {
    if (!autoMaxQualityEnabled) return;
    if (!window.location.hostname.includes('twitch.tv')) return;

    try {
      const pref = localStorage.getItem('video-quality');
      if (!pref || !pref.includes('"chunked"')) {
        localStorage.setItem('video-quality', JSON.stringify({ default: 'chunked' }));
      }
    } catch (e) {}
  }

  window.addEventListener('message', (event) => {
    if (!event.data) return;
    if (event.data.type === 'STREAMSHIELD_QUALITY_CONFIG') {
      autoMaxQualityEnabled = !!event.data.autoMaxQuality;
      if (autoMaxQualityEnabled) {
        handleYouTubeQuality();
        enforceTwitchQuality();
      }
    }
  });

  window.addEventListener('yt-navigate-finish', () => {
    setTimeout(handleYouTubeQuality, 1200);
  });

  setInterval(() => {
    handleYouTubeQuality();
    enforceTwitchQuality();
  }, 2500);

  setTimeout(handleYouTubeQuality, 1000);
  enforceTwitchQuality();
})();
