/**
 * StreamShield - Quality Enforcer (Main World)
 * Forces maximum resolution (HD / 1440p / 4K) on YouTube and Source quality on Twitch.
 */

(function () {
  'use strict';

  let autoMaxQualityEnabled = true;

  function enforceYouTubeQuality() {
    if (!autoMaxQualityEnabled) return;
    if (!window.location.hostname.includes('youtube.com')) return;

    try {
      const player = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
      if (player && typeof player.getAvailableQualityLevels === 'function') {
        const levels = player.getAvailableQualityLevels();
        if (levels && levels.length > 0) {
          // Levels are usually sorted highest to lowest: ['hd2160', 'hd1440', 'hd1080', ...]
          const highest = levels[0];
          const current = typeof player.getPlaybackQuality === 'function' ? player.getPlaybackQuality() : '';

          if (current !== highest && highest !== 'auto') {
            if (typeof player.setPlaybackQualityRange === 'function') {
              player.setPlaybackQualityRange(highest, highest);
            }
            if (typeof player.setPlaybackQuality === 'function') {
              player.setPlaybackQuality(highest);
            }
          }
        }
      }
    } catch (e) {
      // Ignore cross-origin player sandbox
    }
  }

  function enforceTwitchQuality() {
    if (!autoMaxQualityEnabled) return;
    if (!window.location.hostname.includes('twitch.tv')) return;

    try {
      // Set Twitch quality preference to Source ("chunked") in localStorage
      const pref = localStorage.getItem('video-quality');
      if (!pref || !pref.includes('"chunked"')) {
        localStorage.setItem('video-quality', JSON.stringify({ default: 'chunked' }));
      }
    } catch (e) {}
  }

  // Listen for config
  window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'STREAMSHIELD_QUALITY_CONFIG') {
      autoMaxQualityEnabled = !!event.data.autoMaxQuality;
      if (autoMaxQualityEnabled) {
        enforceYouTubeQuality();
        enforceTwitchQuality();
      }
    }
  });

  // YouTube navigation event
  window.addEventListener('yt-navigate-finish', () => {
    setTimeout(enforceYouTubeQuality, 800);
    setTimeout(enforceYouTubeQuality, 2500);
  });

  // Periodic check
  setInterval(() => {
    enforceYouTubeQuality();
    enforceTwitchQuality();
  }, 2000);

  // Initial attempt
  setTimeout(enforceYouTubeQuality, 1000);
  enforceTwitchQuality();
})();
