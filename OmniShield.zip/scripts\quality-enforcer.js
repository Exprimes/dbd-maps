/**
 * OmniShield - Quality Enforcer & MAIN World YouTube Helper
 * Forces maximum resolution (HD / 1440p / 4K) on YouTube and Source quality on Twitch,
 * and triggers native YouTube player ad-skip methods in MAIN world.
 */

(function () {
  'use strict';

  let autoMaxQualityEnabled = true;
  let ytAdblockEnabled = true;

  function handleYouTubeMainWorld() {
    if (!window.location.hostname.includes('youtube.com')) return;

    try {
      const player = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
      if (!player) return;

      const isAd = player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting');

      // 1. If an ad is showing and OmniShield YouTube is enabled, invoke native skipAd if available
      if (isAd && ytAdblockEnabled) {
        if (typeof player.skipAd === 'function') {
          try { player.skipAd(); } catch (e) {}
        }
        return; // Never change video quality while an ad is transitioning
      }

      // 2. Enforce max quality on the main video only (never during ads)
      if (autoMaxQualityEnabled && !isAd && typeof player.getAvailableQualityLevels === 'function') {
        const levels = player.getAvailableQualityLevels();
        if (levels && levels.length > 0) {
          const highest = levels[0];
          const current = typeof player.getPlaybackQuality === 'function' ? player.getPlaybackQuality() : '';

          if (current !== highest && highest !== 'auto') {
            if (typeof player.setPlaybackQualityRange === 'function') {
              player.setPlaybackQualityRange(highest, highest);
            }
            if (typeof player.setPlaybackQuality === 'function') {
              player.setPlaybackQuality(highest);
            }
          }
        }
      }
    } catch (e) {}
  }

  function enforceTwitchQuality() {
    if (!autoMaxQualityEnabled) return;
    if (!window.location.hostname.includes('twitch.tv')) return;

    try {
      const pref = localStorage.getItem('video-quality');
      if (!pref || !pref.includes('"chunked"')) {
        localStorage.setItem('video-quality', JSON.stringify({ default: 'chunked' }));
      }
    } catch (e) {}
  }

  // Listen for config from ISOLATED world
  window.addEventListener('message', (event) => {
    if (!event.data) return;
    if (event.data.type === 'STREAMSHIELD_QUALITY_CONFIG') {
      autoMaxQualityEnabled = !!event.data.autoMaxQuality;
      if (autoMaxQualityEnabled) {
        handleYouTubeMainWorld();
        enforceTwitchQuality();
      }
    } else if (event.data.type === 'OMNISHIELD_YT_CONFIG') {
      ytAdblockEnabled = !!event.data.enabled;
    }
  });

  // YouTube SPA navigation event
  window.addEventListener('yt-navigate-finish', () => {
    setTimeout(handleYouTubeMainWorld, 600);
    setTimeout(handleYouTubeMainWorld, 2000);
  });

  // Periodic check
  setInterval(() => {
    handleYouTubeMainWorld();
    enforceTwitchQuality();
  }, 1000);

  setTimeout(handleYouTubeMainWorld, 800);
  enforceTwitchQuality();
})();
