/**
 * StreamShield - Audio Enhancer (Main World)
 * Web Audio API: Dynamics Compressor (Volume Normalizer) & Gain Booster
 */

(function () {
  'use strict';

  let audioCtx = null;
  let sourceNode = null;
  let compressorNode = null;
  let gainNode = null;
  let attachedVideo = null;

  let normalizerEnabled = false;
  let volumeBoostLevel = 1.0; // 1.0 = 100%, 2.0 = 200%, 3.0 = 300%

  function initAudioContext(video) {
    if (!video || attachedVideo === video) return;

    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;

      if (!audioCtx) {
        audioCtx = new AudioContextClass();
      }

      // Create Web Audio nodes
      sourceNode = audioCtx.createMediaElementSource(video);
      compressorNode = audioCtx.createDynamicsCompressor();
      gainNode = audioCtx.createGain();

      // Configure high-fidelity compressor settings for speech and audio leveling
      compressorNode.threshold.setValueAtTime(-24, audioCtx.currentTime); // dB
      compressorNode.knee.setValueAtTime(30, audioCtx.currentTime);       // dB
      compressorNode.ratio.setValueAtTime(12, audioCtx.currentTime);      // compression ratio
      compressorNode.attack.setValueAtTime(0.003, audioCtx.currentTime);  // 3ms attack
      compressorNode.release.setValueAtTime(0.25, audioCtx.currentTime);  // 250ms release

      updateGraphRouting();

      attachedVideo = video;
      console.log('[StreamShield] Audio Enhancer attached to video.');
    } catch (e) {
      console.warn('[StreamShield] AudioContext initialisation:', e.message);
    }
  }

  function updateGraphRouting() {
    if (!audioCtx || !sourceNode || !gainNode || !compressorNode) return;

    // Disconnect existing graph
    try {
      sourceNode.disconnect();
      compressorNode.disconnect();
      gainNode.disconnect();
    } catch (e) {}

    // Set gain
    gainNode.gain.setValueAtTime(volumeBoostLevel, audioCtx.currentTime);

    if (normalizerEnabled) {
      // Route through compressor then gain then speakers
      sourceNode.connect(compressorNode);
      compressorNode.connect(gainNode);
      gainNode.connect(audioCtx.destination);
    } else if (volumeBoostLevel !== 1.0) {
      // Normalizer OFF, but volume boost is ON
      sourceNode.connect(gainNode);
      gainNode.connect(audioCtx.destination);
    } else {
      // Completely clean bypass
      sourceNode.connect(audioCtx.destination);
    }
  }

  function hookVideoElement() {
    const video = document.querySelector('video');
    if (video && video !== attachedVideo) {
      initAudioContext(video);

      // AudioContext needs resume upon user interaction / play
      const resumeAudio = () => {
        if (audioCtx && audioCtx.state === 'suspended') {
          audioCtx.resume();
        }
      };

      video.addEventListener('play', resumeAudio);
      video.addEventListener('playing', resumeAudio);
      document.addEventListener('click', resumeAudio, { once: true });
    }
  }

  // Listen for config messages from content script
  window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'STREAMSHIELD_AUDIO_CONFIG') {
      normalizerEnabled = !!event.data.normalizer;
      volumeBoostLevel = parseFloat(event.data.boost) || 1.0;

      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume();
      }

      updateGraphRouting();
    }
  });

  // Check periodically for video element
  setInterval(hookVideoElement, 1000);
  hookVideoElement();
})();
