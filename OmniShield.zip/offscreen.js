/**
 * StreamShield - Offscreen Audio Engine (Web Audio API via tabCapture)
 * Bypasses CORS limitations on YouTube/Twitch media CDNs.
 */

let audioCtx = null;
let sourceNode = null;
let compressorNode = null;
let gainNode = null;
let activeStream = null;
let currentStreamId = null;

let isNormalizerActive = false;
let currentVolume = 1.0;

function setupAudioGraph() {
  if (!audioCtx || !sourceNode || !gainNode || !compressorNode) return;

  try {
    sourceNode.disconnect();
    compressorNode.disconnect();
    gainNode.disconnect();
  } catch (e) {}

  gainNode.gain.setValueAtTime(currentVolume, audioCtx.currentTime);

  if (isNormalizerActive) {
    // Route: Source -> Compressor -> Gain -> Speakers
    sourceNode.connect(compressorNode);
    compressorNode.connect(gainNode);
    gainNode.connect(audioCtx.destination);
  } else {
    // Route: Source -> Gain -> Speakers
    sourceNode.connect(gainNode);
    gainNode.connect(audioCtx.destination);
  }
}

async function startCapture(streamId, volume, normalizer) {
  if (currentStreamId === streamId && audioCtx && audioCtx.state === 'running') {
    // Already capturing this stream, just update volume & normalizer
    currentVolume = volume;
    isNormalizerActive = normalizer;
    setupAudioGraph();
    return;
  }

  try {
    if (activeStream) {
      activeStream.getTracks().forEach(t => t.stop());
    }
    if (audioCtx) {
      await audioCtx.close();
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId
        }
      },
      video: false
    });

    activeStream = stream;
    currentStreamId = streamId;
    currentVolume = volume;
    isNormalizerActive = normalizer;

    audioCtx = new AudioContext();

    // Create Nodes
    sourceNode = audioCtx.createMediaStreamSource(stream);
    gainNode = audioCtx.createGain();
    compressorNode = audioCtx.createDynamicsCompressor();

    // Compressor configuration (normalizer)
    compressorNode.threshold.setValueAtTime(-24, audioCtx.currentTime);
    compressorNode.knee.setValueAtTime(30, audioCtx.currentTime);
    compressorNode.ratio.setValueAtTime(12, audioCtx.currentTime);
    compressorNode.attack.setValueAtTime(0.003, audioCtx.currentTime);
    compressorNode.release.setValueAtTime(0.25, audioCtx.currentTime);

    setupAudioGraph();

    if (audioCtx.state === 'suspended') {
      await audioCtx.resume();
    }

    console.log('[StreamShield Offscreen] Tab audio successfully hooked & amplified.');
  } catch (err) {
    console.error('[StreamShield Offscreen] Capture error:', err);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target !== 'offscreen') return;

  if (message.action === 'startBoosting') {
    startCapture(message.streamId, message.volume, message.normalizer).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.action === 'updateVolume') {
    currentVolume = message.volume;
    if (gainNode && audioCtx) {
      gainNode.gain.setTargetAtTime(message.volume, audioCtx.currentTime, 0.01);
    }
    sendResponse({ success: true });
  }

  if (message.action === 'updateNormalizer') {
    isNormalizerActive = message.normalizer;
    setupAudioGraph();
    sendResponse({ success: true });
  }

  if (message.action === 'stopBoosting') {
    if (activeStream) {
      activeStream.getTracks().forEach(t => t.stop());
      activeStream = null;
    }
    if (audioCtx) {
      audioCtx.close();
      audioCtx = null;
    }
    currentStreamId = null;
    sendResponse({ success: true });
  }
});
