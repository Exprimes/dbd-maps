# 🛡️ StreamShield Clean Suite (v1.7.1) - YouTube & Twitch pour Google Chrome

**StreamShield** est une extension pour **Google Chrome** (standard **Manifest V3**) conçue pour éliminer les publicités sur **YouTube** et **Twitch** avec **zéro gêne visuelle**.

---

## ⚡ Fonctionnalités principales

### 1. 🟣 Twitch Clean Stream (Sans écran noir ni coupure)
- **Zéro écran noir, zéro blocage visuel** : Le flux vidéo du stream reste **toujours visible à 100%**. Aucun écran artificiel ou panneau ne vient masquer votre lecteur.
- **Auto-Mute instantané** : Dès qu'une publicité in-stream apparaît, le son est mis en sourdine automatiquement.
- **Pastille discrète** : Une simple petite pastille violette apparaît discrètement dans le coin supérieur droit pour indiquer que le son est coupé, et disparaît aussitôt le direct repris.
- **Suppression intégrale des bannières SDA (Mir, Amazon, etc.)** : La colonne publicitaire verticale entre le lecteur et le tchat est supprimée.

### 2. 🔴 YouTube AdBlock
- **Saut automatique instantané x16** et avance rapide jusqu'à la fin de la pub.
- **Clic automatique** sur le bouton *« Ignorer l'annonce »*.
- **Suppression intégrale des bannières** et pavés sponsorisés.
- **Bypass de la popup anti-adblock**.

### 3. 🎛️ Master Switch instantané
- Un seul clic sur l'interrupteur général désactive ou réactive tous les modules ensemble d'un coup.

### 4. 🔊 Normaliseur & Boost de son (100% à 300%)
- Amplificateur de son direct de 100% à 300% via `tabCapture`.

---

## 🔄 Mise à jour dans Google Chrome

1. Rendez-vous sur :
   ```text
   chrome://extensions/
   ```
2. Cliquez sur l'icône **« Recharger »** 🔄 sur la carte **StreamShield**.
3. Retournez sur Twitch : l'écran noir a totalement disparu, votre stream reste visible en continu !
