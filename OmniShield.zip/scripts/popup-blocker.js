/**
 * OmniShield - Popup / Popunder Blocker (Main World, all sites)
 * Ad scripts listen for clicks on the whole page and open an ad tab, whatever the user clicked.
 * Blocks those, but keeps popups opened by the element actually clicked (login windows, share buttons)
 * and links the user really clicked.
 */

(function () {
  'use strict';

  let lastClickedHref = '';

  // Remember the real link under the user's finger, before any page script runs
  for (const type of ['pointerdown', 'mousedown', 'touchstart', 'click']) {
    window.addEventListener(type, (e) => {
      if (!e.isTrusted) return;
      const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      lastClickedHref = a ? a.href : '';
    }, true);
  }

  function isCrossSite(url) {
    try {
      const u = new URL(url, location.href);
      return /^https?:$/.test(u.protocol) && u.hostname !== location.hostname && u.href !== lastClickedHref;
    } catch (e) {
      return false;
    }
  }

  // A popunder handler is registered on window/document/<html>/<body> to catch clicks anywhere
  function insidePageWideHandler() {
    const ev = window.event;
    if (!ev) return false;
    const ct = ev.currentTarget;
    return ct === window || ct === document || ct === document.documentElement || ct === document.body;
  }

  function report(url) {
    console.log('[OmniShield] Popup bloqué :', String(url).slice(0, 150));
  }

  // shortcut: window.open('') then setting its location, or open() taken from a fresh iframe, gets through; add a tab-close check in background.js if such ads show up
  const realOpen = window.open;
  window.open = function (url, ...rest) {
    if (url && insidePageWideHandler() && isCrossSite(url)) {
      report(url);
      return null;
    }
    return realOpen.call(this, url, ...rest);
  };

  // Fallback trick: the script builds <a target="_blank" href="ad"> and clicks it itself
  window.addEventListener('click', (e) => {
    if (e.isTrusted) return;
    const a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (a && a.target && a.target !== '_self' && isCrossSite(a.href)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      report(a.href);
    }
  }, true);
})();
