/**
 * OmniShield - YouTube Content Script (Zero Black Screen Edition v2.1)
 * Reliable ad speedup (16x) and banner removal without modifying video.currentTime.
 */

(function () {
  'use strict';

  let isEnabled = true;
  let isAdCurrentlyActive = false;
  let originalMutedState = false;
  let originalPlaybackRate = 1.0;

  function updateDOMState() {
    // Tell the MAIN world ad pruner (quality-enforcer.js); localStorage covers the next page load
    window.postMessage({ type: 'OMNISHIELD_YT_STATE', enabled: isEnabled }, '*');
    try {
      if (isEnabled) localStorage.removeItem('omnishield-yt-disabled');
      else localStorage.setItem('omnishield-yt-disabled', '1');
    } catch (e) {}

    if (!document.documentElement) return;
    if (isEnabled) {
      document.documentElement.classList.remove('streamshield-disabled');
      document.documentElement.classList.remove('omnishield-disabled');
    } else {
      document.documentElement.classList.add('streamshield-disabled');
      document.documentElement.classList.add('omnishield-disabled');
      const video = document.querySelector('video.html5-main-video') || document.querySelector('video');
      if (video && isAdCurrentlyActive) {
        video.playbackRate = originalPlaybackRate || 1.0;
        video.muted = originalMutedState;
      }
      isAdCurrentlyActive = false;
    }
  }

  // Sync settings with MAIN world
  function syncSettings() {
    chrome.storage.local.get(
      [
        'streamShieldEnabled',
        'youtubeEnabled',
        'autoMaxQuality',
        'volumeNormalize',
        'volumeBoost'
      ],
      (res) => {
        isEnabled = (res.streamShieldEnabled !== false) && (res.youtubeEnabled !== false);
        updateDOMState();

        window.postMessage({
          type: 'STREAMSHIELD_AUDIO_CONFIG',
          normalizer: isEnabled ? (res.volumeNormalize ?? false) : false,
          boost: isEnabled ? (res.volumeBoost ?? 1.0) : 1.0
        }, '*');

        window.postMessage({
          type: 'STREAMSHIELD_QUALITY_CONFIG',
          autoMaxQuality: isEnabled ? (res.autoMaxQuality ?? true) : false
        }, '*');
      }
    );
  }

  syncSettings();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.streamShieldEnabled !== undefined || changes.youtubeEnabled !== undefined) {
        chrome.storage.local.get(['streamShieldEnabled', 'youtubeEnabled'], (res) => {
          isEnabled = (res.streamShieldEnabled !== false) && (res.youtubeEnabled !== false);
          updateDOMState();
        });
      }

      if (changes.volumeNormalize !== undefined || changes.volumeBoost !== undefined) {
        chrome.storage.local.get(['volumeNormalize', 'volumeBoost', 'streamShieldEnabled'], (res) => {
          const active = res.streamShieldEnabled !== false;
          window.postMessage({
            type: 'STREAMSHIELD_AUDIO_CONFIG',
            normalizer: active ? (res.volumeNormalize ?? false) : false,
            boost: active ? (res.volumeBoost ?? 1.0) : 1.0
          }, '*');
        });
      }

      if (changes.autoMaxQuality !== undefined) {
        chrome.storage.local.get(['streamShieldEnabled'], (res) => {
          const active = res.streamShieldEnabled !== false;
          window.postMessage({
            type: 'STREAMSHIELD_QUALITY_CONFIG',
            autoMaxQuality: active ? changes.autoMaxQuality.newValue : false
          }, '*');
        });
      }
    }
  });

  function reportBlockedAd(count = 1) {
    if (!isEnabled) return;
    chrome.runtime.sendMessage({ action: 'adBlocked', platform: 'youtube', count }).catch(() => {});
  }

  function cleanBanners() {
    if (!isEnabled) return;

    const bannerSelectors = [
      'ytd-ad-slot-renderer',
      'ytd-in-feed-ad-layout-renderer',
      '#masthead-ad',
      'ytd-banner-promo-renderer',
      'ytd-statement-banner-renderer',
      'ytd-promoted-sparkles-web-renderer',
      'ytd-promoted-sparkles-text-search-renderer',
      'ytd-display-ad-renderer',
      '#player-ads',
      '.ytd-player-legacy-desktop-watch-ads-renderer',
      'ytd-action-companion-ad-renderer',
      'ytd-companion-slot-renderer',
      'ytd-compact-promoted-video-renderer'
    ];

    let found = 0;
    for (const selector of bannerSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const el of elements) {
        if (!el.dataset.ssBlocked) {
          el.dataset.ssBlocked = 'true';
          el.style.display = 'none';
          found++;
        }
      }
    }

    if (found > 0) {
      reportBlockedAd(found);
    }
  }

  function handleAntiAdblockModal() {
    if (!isEnabled) return;

    const enforcementEl = document.querySelector('ytd-enforcement-message-view-model');
    if (enforcementEl) {
      const dialog = enforcementEl.closest('tp-yt-paper-dialog') || enforcementEl;
      const dismissBtn = dialog.querySelector('#dismiss-button, button[aria-label*="Fermer"], button[aria-label*="Dismiss"], yt-button-renderer button');
      if (dismissBtn) {
        dismissBtn.click();
      } else {
        dialog.remove();
      }

      const backdrop = document.querySelector('tp-yt-iron-overlay-backdrop');
      if (backdrop) backdrop.remove();

      const video = document.querySelector('video.html5-main-video') || document.querySelector('video');
      if (video && video.paused) {
        video.play().catch(() => {});
      }

      reportBlockedAd(1);
    }
  }

  function clickSkipButtons(moviePlayer) {
    const skipSelectors = [
      '.ytp-ad-skip-button',
      '.ytp-ad-skip-button-modern',
      '.ytp-skip-ad-button',
      '.ytp-ad-skip-button-slot button',
      '.ytp-ad-skip-button-container button',
      '[id^="skip-button"] button',
      '.ytp-ad-overlay-close-button'
    ];

    for (const selector of skipSelectors) {
      const buttons = moviePlayer.querySelectorAll(selector);
      for (const btn of buttons) {
        try {
          btn.click();
        } catch (e) {}
      }
    }
  }

  function processVideoAds() {
    if (!isEnabled) return;

    const moviePlayer = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
    if (!moviePlayer) return;

    const video = moviePlayer.querySelector('video.html5-main-video') || moviePlayer.querySelector('video');
    if (!video) return;

    // Strictly check YouTube's official ad-state classes on #movie_player
    const isAdShowing = moviePlayer.classList.contains('ad-showing') ||
                        moviePlayer.classList.contains('ad-interrupting');

    if (isAdShowing) {
      if (!isAdCurrentlyActive) {
        isAdCurrentlyActive = true;
        originalMutedState = video.muted;
        originalPlaybackRate = (video.playbackRate && video.playbackRate <= 2.0) ? video.playbackRate : 1.0;
        reportBlockedAd(1);
      }

      // 1. Mute ad immediately
      if (!video.muted) {
        video.muted = true;
      }

      // 2. Play if paused (prevents frozen black screen)
      if (video.paused && !video.ended) {
        video.play().catch(() => {});
      }

      // 3. Speed up ad to 16x (DO NOT touch currentTime — 16x plays a 5s ad in 300ms smoothly)
      if (video.playbackRate < 16.0) {
        try {
          video.playbackRate = 16.0;
        } catch (e) {
          try { video.playbackRate = 8.0; } catch (e2) {}
        }
      }

      // 4. Click any skip button that appears
      clickSkipButtons(moviePlayer);
    } else {
      // Close overlay ad if present
      const closeOverlayBtn = moviePlayer.querySelector('.ytp-ad-overlay-close-button');
      if (closeOverlayBtn) {
        try { closeOverlayBtn.click(); } catch (e) {}
      }

      if (isAdCurrentlyActive) {
        isAdCurrentlyActive = false;
        video.muted = originalMutedState;
        video.playbackRate = originalPlaybackRate || 1.0;

        // Ensure main video resumes smoothly
        if (video.paused && !video.ended) {
          video.play().catch(() => {});
        }
      }
    }

    handleAntiAdblockModal();
  }

  setInterval(processVideoAds, 100);
  setInterval(cleanBanners, 1000);

  const startObserver = () => {
    if (!document.documentElement) return;
    const observer = new MutationObserver(() => {
      if (!isEnabled) return;
      processVideoAds();
      cleanBanners();
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });
  };

  if (document.documentElement) {
    startObserver();
  } else {
    window.addEventListener('DOMContentLoaded', startObserver);
  }

  console.log('[OmniShield] YouTube Native Engine v2.1 active.');
})();
