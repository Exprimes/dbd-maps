/**
 * OmniShield - Twitch Content Script (VAFT Companion v2.0)
 * Works alongside twitch-interceptor.js (VAFT engine) to:
 * 1. Sync Master Switch / Twitch toggle state with the MAIN world VAFT worker
 * 2. Increment the blocked ad counter when VAFT intercepts an HLS ad stream
 * 3. Remove Stream Display Ads (vertical SDA banners between player & chat)
 */

(function () {
  'use strict';

  let isEnabled = true;

  function syncStateToMainWorld() {
    window.postMessage({ type: 'STREAMSHIELD_STATE', enabled: isEnabled }, '*');
    window.postMessage({ type: 'OMNISHIELD_STATE', enabled: isEnabled }, '*');
    if (document.documentElement) {
      if (isEnabled) {
        document.documentElement.classList.remove('streamshield-disabled');
        document.documentElement.classList.remove('omnishield-disabled');
      } else {
        document.documentElement.classList.add('streamshield-disabled');
        document.documentElement.classList.add('omnishield-disabled');
      }
    }
  }

  // Retrieve initial settings
  chrome.storage.local.get(['streamShieldEnabled', 'twitchEnabled'], (res) => {
    isEnabled = (res.streamShieldEnabled !== false) && (res.twitchEnabled !== false);
    syncStateToMainWorld();
  });

  // Listen for setting changes from popup
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.streamShieldEnabled !== undefined || changes.twitchEnabled !== undefined) {
        chrome.storage.local.get(['streamShieldEnabled', 'twitchEnabled'], (res) => {
          isEnabled = (res.streamShieldEnabled !== false) && (res.twitchEnabled !== false);
          syncStateToMainWorld();
        });
      }
    }
  });

  function reportBlockedAd(count = 1) {
    if (!isEnabled) return;
    chrome.runtime.sendMessage({ action: 'adBlocked', platform: 'twitch', count }).catch(() => {});
  }

  // Listen for VAFT ad-block notifications from MAIN world (twitch-interceptor.js)
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return;
    if ((event.data.type === 'STREAMSHIELD_AD_BLOCKED' || event.data.type === 'OMNISHIELD_AD_BLOCKED') && event.data.platform === 'twitch') {
      reportBlockedAd(1);
    }
  });

  // Remove vertical Stream Display Ads (SDA banner between player & chat)
  function cleanStreamDisplayAds() {
    if (!isEnabled) return;

    const sdaSelectors = [
      '[data-test-selector="stream-display-ad"]',
      '[data-a-target="stream-display-ad"]',
      '.stream-display-ad',
      'div[class*="stream-display-ad"]',
      'iframe[src*="amazon-adsystem"]',
      'iframe[src*="doubleclick"]',
      'div[data-a-target="top-nav-ad-container"]',
      'div[data-target="frontpage-ad-billboard"]'
    ];

    for (const sel of sdaSelectors) {
      document.querySelectorAll(sel).forEach((el) => {
        const wrapper = el.closest('[data-test-selector="stream-display-ad"]') ||
                        el.closest('div[class*="stream-display"]') ||
                        el;
        if (wrapper && !wrapper.dataset.ssRemoved) {
          wrapper.dataset.ssRemoved = 'true';
          wrapper.remove();
          reportBlockedAd(1);
        }
      });
    }

    // Catch Amazon AdSystem links between player and chat
    document.querySelectorAll('a[href*="amazon-adsystem"], a[href*="doubleclick"]').forEach((link) => {
      let node = link;
      let target = null;
      while (node && node !== document.body) {
        if (node.classList && (node.classList.contains('chat-room') || node.classList.contains('video-player'))) {
          target = null;
          break;
        }
        if (node.offsetWidth > 40 && node.offsetHeight > 40) {
          target = node;
        }
        node = node.parentElement;
      }

      if (target && !target.dataset.ssRemoved) {
        target.dataset.ssRemoved = 'true';
        target.remove();
        reportBlockedAd(1);
      }
    });
  }

  setInterval(cleanStreamDisplayAds, 500);

  const startObserver = () => {
    if (!document.documentElement) return;
    const observer = new MutationObserver(() => {
      if (!isEnabled) return;
      cleanStreamDisplayAds();
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  };

  if (document.documentElement) {
    startObserver();
  } else {
    window.addEventListener('DOMContentLoaded', startObserver);
  }
})();
