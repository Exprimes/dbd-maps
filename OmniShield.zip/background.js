/**
 * StreamShield - Background Service Worker (Manifest V3)
 */

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(
    [
      'streamShieldEnabled',
      'youtubeEnabled',
      'twitchEnabled',
      'autoMaxQuality',
      'volumeNormalize',
      'volumeBoost',
      'totalBlocked',
      'youtubeBlocked',
      'twitchBlocked'
    ],
    (res) => {
      const isMaster = res.streamShieldEnabled ?? true;
      const total = res.totalBlocked ?? 0;
      chrome.storage.local.set({
        streamShieldEnabled: isMaster,
        youtubeEnabled: res.youtubeEnabled ?? true,
        twitchEnabled: res.twitchEnabled ?? true,
        autoMaxQuality: res.autoMaxQuality ?? true,
        volumeNormalize: res.volumeNormalize ?? false,
        volumeBoost: res.volumeBoost ?? 1.0,
        totalBlocked: total,
        youtubeBlocked: res.youtubeBlocked ?? 0,
        twitchBlocked: res.twitchBlocked ?? 0
      });

      if (isMaster) {
        updateBadge(total);
      } else {
        setOffBadge();
      }
    }
  );
});

// Update badge display on extension icon
function updateBadge(count) {
  try {
    if (count > 0) {
      const text = count > 999 ? '999+' : count.toString();
      chrome.action.setBadgeText({ text });
      chrome.action.setBadgeBackgroundColor({ color: '#a855f7' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (e) {}
}

function setOffBadge() {
  try {
    chrome.action.setBadgeText({ text: 'OFF' });
    chrome.action.setBadgeBackgroundColor({ color: '#6b7280' });
  } catch (e) {}
}

// Initial badge update on browser startup
chrome.storage.local.get(['totalBlocked', 'streamShieldEnabled'], (res) => {
  if (!chrome.runtime.lastError) {
    if (res.streamShieldEnabled === false) {
      setOffBadge();
    } else {
      updateBadge(res.totalBlocked ?? 0);
    }
  }
});

// Ensure offscreen document exists for Web Audio processing safely
async function setupOffscreenDocument() {
  if (!chrome.offscreen) return;

  try {
    if (chrome.offscreen.hasDocument && await chrome.offscreen.hasDocument()) {
      return;
    }

    if (chrome.runtime.getContexts) {
      const existing = await chrome.runtime.getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT']
      });
      if (existing.length > 0) {
        return;
      }
    }

    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['USER_MEDIA'],
      justification: 'Captures and amplifies tab audio cleanly without CORS restrictions.'
    });
  } catch (err) {
    if (!err.message?.includes('single offscreen document')) {
      console.warn('[StreamShield] Offscreen setup note:', err.message);
    }
  }
}

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Master Switch toggling
  if (message.action === 'masterToggled') {
    const isMaster = !!message.enabled;

    if (isMaster) {
      // Re-enable network ruleset
      if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateEnabledRulesets) {
        chrome.declarativeNetRequest.updateEnabledRulesets({
          enableRulesetIds: ['ad_rules']
        }).catch(() => {});
      }
      chrome.storage.local.get(['totalBlocked'], (res) => {
        updateBadge(res.totalBlocked ?? 0);
      });
    } else {
      // Disable network ruleset
      if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateEnabledRulesets) {
        chrome.declarativeNetRequest.updateEnabledRulesets({
          disableRulesetIds: ['ad_rules']
        }).catch(() => {});
      }
      // Stop any active audio boosting
      chrome.runtime.sendMessage({ target: 'offscreen', action: 'stopBoosting' }).catch(() => {});
      setOffBadge();
    }

    sendResponse({ success: true, enabled: isMaster });
    return true;
  }

  if (message.action === 'adBlocked') {
    const count = parseInt(message.count, 10) || 1;
    chrome.storage.local.get(['totalBlocked', 'youtubeBlocked', 'twitchBlocked', 'streamShieldEnabled'], (res) => {
      if (chrome.runtime.lastError || res.streamShieldEnabled === false) {
        sendResponse({ success: false });
        return;
      }

      const total = (res.totalBlocked || 0) + count;
      const yt = (res.youtubeBlocked || 0) + (message.platform === 'youtube' ? count : 0);
      const tw = (res.twitchBlocked || 0) + (message.platform === 'twitch' ? count : 0);

      chrome.storage.local.set({
        totalBlocked: total,
        youtubeBlocked: yt,
        twitchBlocked: tw
      }, () => {
        updateBadge(total);
        sendResponse({ success: true, total });
      });
    });
    return true;
  }

  // Audio Booster via tabCapture & Offscreen Document
  if (message.action === 'boostTabAudio') {
    if (!message.tabId) {
      sendResponse({ error: 'No tabId provided' });
      return false;
    }

    chrome.tabs.get(message.tabId, (tab) => {
      if (chrome.runtime.lastError || !tab || !tab.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
        sendResponse({ error: 'Unsupported tab' });
        return;
      }

      (async () => {
        try {
          await setupOffscreenDocument();

          chrome.tabCapture.getMediaStreamId({ targetTabId: message.tabId }, (streamId) => {
            if (chrome.runtime.lastError) {
              sendResponse({ error: chrome.runtime.lastError.message });
              return;
            }

            chrome.runtime.sendMessage({
              target: 'offscreen',
              action: 'startBoosting',
              streamId: streamId,
              volume: message.volume || 1.0,
              normalizer: !!message.normalizer
            }, (res) => {
              if (chrome.runtime.lastError) {
                sendResponse({ success: false });
                return;
              }
              sendResponse(res || { success: true });
            });
          });
        } catch (err) {
          sendResponse({ error: err.message });
        }
      })();
    });
    return true;
  }

  if (message.action === 'updateTabVolume') {
    chrome.runtime.sendMessage({
      target: 'offscreen',
      action: 'updateVolume',
      volume: message.volume || 1.0
    }, (res) => {
      if (chrome.runtime.lastError) return;
      sendResponse(res || { success: true });
    });
    return true;
  }

  if (message.action === 'updateTabNormalizer') {
    chrome.runtime.sendMessage({
      target: 'offscreen',
      action: 'updateNormalizer',
      normalizer: !!message.normalizer
    }, (res) => {
      if (chrome.runtime.lastError) return;
      sendResponse(res || { success: true });
    });
    return true;
  }
});
