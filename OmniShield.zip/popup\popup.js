/**
 * StreamShield - Popup Controller v1.5 (True Master Switch)
 */

document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const masterToggle = document.getElementById('masterToggle');
  const youtubeToggle = document.getElementById('youtubeToggle');
  const twitchToggle = document.getElementById('twitchToggle');
  const autoQualityToggle = document.getElementById('autoQualityToggle');
  const normalizerToggle = document.getElementById('normalizerToggle');
  const boostSlider = document.getElementById('boostSlider');
  const boostVal = document.getElementById('boostVal');
  const resetBtn = document.getElementById('resetBtn');
  const modulesWrapper = document.getElementById('modulesWrapper');

  const totalBlockedCount = document.getElementById('totalBlockedCount');
  const ytBlockedCount = document.getElementById('ytBlockedCount');
  const twBlockedCount = document.getElementById('twBlockedCount');

  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');

  let activeTabId = null;
  let isTabSupported = false;

  function updateStatusUI(isActive) {
    if (isActive) {
      statusDot.className = 'dot active';
      statusText.textContent = 'Protection active';
      modulesWrapper.classList.remove('disabled');
    } else {
      statusDot.className = 'dot';
      statusText.textContent = 'Protection complètement désactivée';
      modulesWrapper.classList.add('disabled');
    }
  }

  // Get current active tab safely
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs[0]) {
      activeTabId = tabs[0].id;
      const url = tabs[0].url || '';
      isTabSupported = url.startsWith('http://') || url.startsWith('https://');
    }
  });

  // Apply audio boost safely
  function applyAudioSettings(multiplier, isNormalizer) {
    if (!activeTabId || !isTabSupported) return;

    chrome.runtime.sendMessage({
      action: 'boostTabAudio',
      tabId: activeTabId,
      volume: multiplier,
      normalizer: isNormalizer
    }, () => {
      if (chrome.runtime.lastError) return;
      chrome.runtime.sendMessage({ action: 'updateTabVolume', volume: multiplier });
      chrome.runtime.sendMessage({ action: 'updateTabNormalizer', normalizer: isNormalizer });
    });
  }

  // Load state from chrome.storage
  chrome.storage.local.get(
    [
      'streamShieldEnabled',
      'youtubeEnabled',
      'twitchEnabled',
      'autoMaxQuality',
      'volumeNormalize',
      'volumeBoost',
      'totalBlocked',
      'youtubeBlocked',
      'twitchBlocked'
    ],
    (res) => {
      const isMaster = res.streamShieldEnabled ?? true;
      masterToggle.checked = isMaster;

      youtubeToggle.checked = isMaster && (res.youtubeEnabled ?? true);
      twitchToggle.checked = isMaster && (res.twitchEnabled ?? true);
      autoQualityToggle.checked = isMaster && (res.autoMaxQuality ?? true);
      normalizerToggle.checked = isMaster && (res.volumeNormalize ?? false);

      const boost = isMaster ? Math.round((res.volumeBoost ?? 1.0) * 100) : 100;
      boostSlider.value = boost;
      boostVal.textContent = boost + '%';

      totalBlockedCount.textContent = (res.totalBlocked ?? 0).toLocaleString();
      ytBlockedCount.textContent = (res.youtubeBlocked ?? 0).toLocaleString();
      twBlockedCount.textContent = (res.twitchBlocked ?? 0).toLocaleString();

      updateStatusUI(isMaster);
    }
  );

  // Master switch: Turns EVERYTHING ON or EVERYTHING OFF
  masterToggle.addEventListener('change', () => {
    const isMaster = masterToggle.checked;

    // Immediately toggle all UI controls
    youtubeToggle.checked = isMaster;
    twitchToggle.checked = isMaster;
    autoQualityToggle.checked = isMaster;
    normalizerToggle.checked = false;

    if (!isMaster) {
      boostSlider.value = 100;
      boostVal.textContent = '100%';
    }

    updateStatusUI(isMaster);

    // Save state in storage
    chrome.storage.local.set({
      streamShieldEnabled: isMaster,
      youtubeEnabled: isMaster,
      twitchEnabled: isMaster,
      autoMaxQuality: isMaster,
      volumeNormalize: false,
      volumeBoost: 1.0
    });

    // Notify background to toggle network rules and audio
    chrome.runtime.sendMessage({
      action: 'masterToggled',
      enabled: isMaster
    });
  });

  // Individual Toggles
  youtubeToggle.addEventListener('change', () => {
    chrome.storage.local.set({ youtubeEnabled: youtubeToggle.checked });
  });

  twitchToggle.addEventListener('change', () => {
    chrome.storage.local.set({ twitchEnabled: twitchToggle.checked });
  });

  autoQualityToggle.addEventListener('change', () => {
    chrome.storage.local.set({ autoMaxQuality: autoQualityToggle.checked });
  });

  // Normalizer toggle
  normalizerToggle.addEventListener('change', () => {
    const isNormalizer = normalizerToggle.checked;
    chrome.storage.local.set({ volumeNormalize: isNormalizer });
    const multiplier = parseInt(boostSlider.value, 10) / 100.0;
    applyAudioSettings(multiplier, isNormalizer);
  });

  // Volume Boost Slider
  boostSlider.addEventListener('input', () => {
    const val = parseInt(boostSlider.value, 10);
    boostVal.textContent = val + '%';
    const multiplier = (val / 100.0);
    chrome.storage.local.set({ volumeBoost: multiplier });

    applyAudioSettings(multiplier, normalizerToggle.checked);
  });

  // Reset Stats
  resetBtn.addEventListener('click', () => {
    if (confirm('Voulez-vous réinitialiser tous les compteurs ?')) {
      chrome.storage.local.set({
        totalBlocked: 0,
        youtubeBlocked: 0,
        twitchBlocked: 0
      }, () => {
        totalBlockedCount.textContent = '0';
        ytBlockedCount.textContent = '0';
        twBlockedCount.textContent = '0';
        chrome.action.setBadgeText({ text: '' });
      });
    }
  });

  // Real-time counter updates
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.totalBlocked !== undefined) {
        totalBlockedCount.textContent = (changes.totalBlocked.newValue ?? 0).toLocaleString();
      }
      if (changes.youtubeBlocked !== undefined) {
        ytBlockedCount.textContent = (changes.youtubeBlocked.newValue ?? 0).toLocaleString();
      }
      if (changes.twitchBlocked !== undefined) {
        twBlockedCount.textContent = (changes.twitchBlocked.newValue ?? 0).toLocaleString();
      }
    }
  });
});
